from os import listdir
from os.path import isfile, join, realpath, dirname
import pickle
import random

test_or_train = None
while test_or_train not in ["test", "train"]:
    test_or_train = input("Parse test or train? >")
    
if test_or_train == 'train':
    path = dirname(realpath(__file__)) + "\\aclImdb\\train"
else:
    path = dirname(realpath(__file__)) + "\\aclImdb\\test"

pos_texts = [f for f in listdir(path + "\\pos") if isfile(join(path + "\\pos", f))]
neg_texts = [f for f in listdir(path + "\\neg") if isfile(join(path + "\\neg", f))]

SENT_DICT = {i: [] for i in range(1,11)}
SAMPLE_SIZE = int(int(input("How many samples? (max. 25000) >"))/2)

for f in random.sample(pos_texts, SAMPLE_SIZE):
    rating = f.split("_")[-1][:-4]
    with open(path + "\\pos\\" + f) as data:
        SENT_DICT[int(rating)].append(data.readlines()[0])

for f in random.sample(neg_texts, SAMPLE_SIZE):
    rating = f.split("_")[-1][:-4]
    with open(path + "\\neg\\" + f) as data:
        SENT_DICT[int(rating)].append(data.readlines()[0])

pickle.dump(SENT_DICT, open("database_{}.pydb".format(test_or_train), "wb"))
print("Pickled {} random positive reviews and {} random negative reviews.".format(SAMPLE_SIZE, SAMPLE_SIZE))
