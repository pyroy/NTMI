import pickle

# DATA[1] contains a list of all reviews that gave the movie 1 star.
# DATA[2] the same with 2 stars etc.
#
# Please re-run parser.bat if you want to change the sample size.

TRAINING_DATA = pickle.load(open("database_train.pydb","rb"))
TEST_DATA = pickle.load(open("database_test.pydb","rb"))
